import React, { useState } from 'react'
import './CreateEmp.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function CreateEmp() {

  const [name, setName]=useState('');
  const [age, setAge]=useState('');
  const [address, setAddress]=useState('');
  const [emp_reg, setEmp_reg]=useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try{
      const response = await axios.post('http://localhost:3000/Createuser',{
        name: name,
        age: age,
        address: address,
        emp_reg:emp_reg
      })
      navigate('/')
    }catch(error){
      console.log("error = "+error)
    }
    
  };


  return (
    <div className='frmdiv'>
      <form className='frm'>
      <h1 className='frmh1'>ADD EMPLOYEE</h1>
      <label>
        Name:
        <input type="text" name="name" onChange={(event)=>setName(event.target.value)} />
      </label>

      <label>
        Age:
        <input type="text" name="age" onChange={(event)=>setAge(event.target.value)} />
      </label>

      <label>
        Address:
        <input type="text" name="address" onChange={(event)=>setAddress(event.target.value)} />
      </label>

      <label>
        Employee Registration:
        <input type="text" name="emp_reg" onChange={(event)=>setEmp_reg(event.target.value)} />
      </label>

      <button onClick={handleSubmit} type="submit">Submit</button>
    </form>
    </div>
  )
}

export default CreateEmp