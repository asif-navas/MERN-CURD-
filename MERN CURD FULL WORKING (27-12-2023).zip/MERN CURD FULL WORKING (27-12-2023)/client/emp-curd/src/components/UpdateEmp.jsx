import React, { useState,useEffect } from "react";
import './CreateEmp.css';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

function UpdateEmp() {

  const {id}=useParams()

  const [name, setName]=useState('');
  const [age, setAge]=useState('');
  const [address, setAddress]=useState('');
  const [emp_reg, setEmp_reg]=useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:3000/Emp/'+id);
        setName(response.data.name);
        setAge(response.data.age);
        setAddress(response.data.address);
        setEmp_reg(response.data.emp_reg);
      } catch (err) {
        console.error('Error:', err);
      }
    };
  
    fetchData();
    
  },[])


  const handelupdate = async (e) => {
    e.preventDefault();
    try{
       await axios.patch('http://localhost:3000/update/'+id,{
        name:name,
        age:age,
        address:address,
        emp_reg:emp_reg
      });
      
      navigate('/')
    }catch (err) {
      console.error('Error:', err);
    }
  }



  return (
    <div className="frmdiv">
      <form className="frm">
        <h1 className="frmh1">UPDATE EMPLOYEE</h1>
        <label>
          Name:
          <input
            type="text"
            name="name"
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
        </label>

        <label>
          Age:
          <input
            type="text"
            name="age"
            value={age}
            onChange={(event) => setAge(event.target.value)}
          />
        </label>

        <label>
          Address:
          <input
            type="text"
            name="address"
            value={address}
            onChange={(event) => setAddress(event.target.value)}
          />
        </label>

        <label>
          Employee Registration:
          <input
            type="text"
            name="emp_reg"
            value={emp_reg}
            onChange={(event) => setEmp_reg(event.target.value)}
          />
        </label>

        <button onClick={handelupdate} type="submit">Update</button>
      </form>
    </div>
  );
}

export default UpdateEmp;
