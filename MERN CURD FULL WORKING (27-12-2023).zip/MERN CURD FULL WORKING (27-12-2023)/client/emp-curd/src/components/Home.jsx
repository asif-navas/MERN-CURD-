import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Link, useNavigate } from 'react-router-dom';
import './Home.css';

function Home() {
    const navigate = useNavigate();

    const [empDetails, setEmpDetails] = useState([]);


    useEffect(() => {
        const fetchData = async () => {
          try {
            const response = await axios.get('http://localhost:3000');
            setEmpDetails(response.data);
          } catch (err) {
            console.error('Error:', err);
          }
        };
      
        fetchData();
      }, []);

      const handdledelete = async (id) => {
        try{
           await axios.delete('http://localhost:3000/delete/'+id);
        
        window.location.reload();
        // navigate('/')
        }catch (err){
            console.error('Error:', err);
        }
        

      }
      

  return (
    <div className='Mhome'>

        <Link className='add' to='/Creater'>ADD EMPLOYEE +</Link>
        
        <h1 className='h1home'>Employee Details</h1>

        {
            empDetails.map((users,index) =>{
                return (
                    <div key={index}>
                    <p className='mp'>Name : {users.name}</p> 
                    <p className='mp'>Age : {users.age}</p> 
                    <p className='mp'>Address : {users.address}</p> 
                    <p className='mp'>Emp Id : {users.emp_reg}</p>
                    <Link  className='upbtn' to={`/Update/${users._id}`}>UPDATE</Link>
                    <button className='delbtn' onClick={(e) => handdledelete(users._id)}>Delete</button>
                
                </div>
                )
                
            })
        }

    </div>
  )
}

export default Home