import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./components/Home";
import CreateEmp from "./components/CreateEmp";
import UpdateEmp from "./components/UpdateEmp";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/Creater" element={<CreateEmp />}></Route>
        <Route path="/Update/:id" element={<UpdateEmp />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
