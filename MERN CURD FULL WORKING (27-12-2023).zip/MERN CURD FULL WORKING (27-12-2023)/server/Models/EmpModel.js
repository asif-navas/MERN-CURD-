const mongoose = require('mongoose');
const EmpSchema = new mongoose.Schema (

    {
        "name": {
          "type": "String"
          
        },

        "age": {
            "type": "Number"
            
          },
  
        "address": {
          "type": "String"
         
        },

        "emp_reg": {
          "type": "String"
         
        }
      }
);

const EmpModel = mongoose.model('employee',EmpSchema);
module.exports = EmpModel;
