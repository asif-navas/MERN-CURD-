const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const EmpModel = require('./Models/EmpModel');

const app = express();

// middleware
app.use(cors());
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

// mongoDB connection

mongoose.connect("mongodb://localhost:27017/EMP-CURD")
const db=mongoose.connection;
db.on('error',console.error.bind(console,"conection error"));
db.once('open',function(){
    console.log(" Mongo DB Connected sucessfully")
});


//ADD User
app.post('/Createuser', async (req,res)=>{
    try{
        const response = await EmpModel.create(req.body)
        .then (response => res.json(response));

    }catch(error){
        console.log('Error is '+error)
    }

    }
)

//Get All Users
app.get('/', async (req,res)=>{
    try{
        const response = await EmpModel.find()
        .then (response => res.json(response));
    }catch(error){
        console.log('Error is '+error)
    }
})

app.get('/Emp/:id', async (req,res)=>{
    try{
        const id = req.params.id;
        await EmpModel.findById({_id:id})
        .then (response => res.json(response));
    }catch(error){
        console.log('Error is '+error)
    }
})

app.patch('/update/:id', async (req,res)=>{
    try{
        const id = req.params.id;
        await EmpModel.findByIdAndUpdate({_id:id},{
            name: req.body.name,
            age: req.body.age,
            address: req.body.address,
            emp_reg: req.body.emp_reg
        })
        .then(response => res.json(response)) ;
    }catch(error){
        console.log('Error is '+error)
    }
})


app.delete('/delete/:id', async (req,res)=>{
    try{
        const id = req.params.id;
        await EmpModel.findByIdAndDelete({_id:id})
        .then(response => res.json(response))
    }catch(error){
        console.log('Error is '+error)
    }
})

app.listen(3000,() => 
console.log("port is running port = 3000")
);